package application.spiel.spielfelder;

import application.gui.SpielfeldController;

public abstract class Spielfeld
{
	public abstract void funktion(SpielfeldController sc);
}
