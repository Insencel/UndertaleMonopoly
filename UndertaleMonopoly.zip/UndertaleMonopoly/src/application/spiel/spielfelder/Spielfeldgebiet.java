package application.spiel.spielfelder;

public enum Spielfeldgebiet {
RUINS, SNOWDIN_FOREST, SNOWDIN, WATERFALL, HOTLAND, HOTEL, CORE, END
}
