package application.spiel.spielfelder;

import application.gui.SpielfeldController;

public class SpielfeldOhneFunktion extends Spielfeld{

	@Override
	public void funktion(SpielfeldController sc) {
		//(LOS und Frei Parken)
		sc.spielfeldEventTextAnzeigen();
	}

}
