package application.spiel;

public class SpielerGefangenException extends Throwable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7129179178731881552L;

}
