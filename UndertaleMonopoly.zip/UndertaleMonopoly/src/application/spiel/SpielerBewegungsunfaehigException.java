package application.spiel;

public class SpielerBewegungsunfaehigException extends Throwable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7129179178731881552L;
}
