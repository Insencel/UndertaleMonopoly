package application.datenbankanbindung;

public enum UpdateEnum {
besitzer, haeuser, amZug, paschcounter, gold, position, gefaengnis, paralyse, 
}
